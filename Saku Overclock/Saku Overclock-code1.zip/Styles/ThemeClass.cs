﻿namespace Saku_Overclock.Styles;
public class ThemeClass
{
    public string ThemeName = "New  Theme";
    public bool ThemeLight = true;
    public bool ThemeCustom = false;
    public double ThemeOpacity = 0.5;
    public double ThemeMaskOpacity = 1.0;
    public bool ThemeCustomBg = false;
    public string ThemeBackground = "";
}

﻿using System.Collections.Generic;

namespace Saku_Overclock;
internal class Powercfg
{
    public List<string> _notelist { get; set; } = [];
}

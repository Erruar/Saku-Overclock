﻿namespace Saku_Overclock.SMUEngine;
public class InfoPageCPUPoints
{
    public int X { get; set; } // Время (от 0 до 60)
    public int Y { get; set; } // Инвертированное значение
}

﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Saku_Overclock.ViewModels;
public partial class AdvancedКулерViewModel : ObservableRecipient
{
    public AdvancedКулерViewModel()
    {
    }
}

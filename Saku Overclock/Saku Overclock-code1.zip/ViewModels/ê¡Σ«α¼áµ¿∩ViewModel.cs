﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Saku_Overclock.ViewModels;

public partial class ИнформацияViewModel : ObservableRecipient
{
    public ИнформацияViewModel()
    {
    }
}

﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Saku_Overclock.ViewModels;

public partial class КулерViewModel : ObservableRecipient
{
    public КулерViewModel()
    {
    }
}

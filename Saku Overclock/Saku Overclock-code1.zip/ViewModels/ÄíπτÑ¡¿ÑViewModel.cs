﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Saku_Overclock.ViewModels;

public partial class ОбучениеViewModel : ObservableRecipient
{
    public ОбучениеViewModel() { }
}

﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Saku_Overclock.ViewModels;

public partial class ПараметрыViewModel : ObservableRecipient 
{ 
    public ПараметрыViewModel()
    { 
    } 
}

﻿namespace Saku_Overclock.Contracts.Services;

public interface IPageService
{
    Type GetPageType(string key);
}

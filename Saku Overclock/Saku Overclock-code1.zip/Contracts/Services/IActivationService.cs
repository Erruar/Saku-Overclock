﻿namespace Saku_Overclock.Contracts.Services;

public interface IActivationService
{
    Task ActivateAsync(object activationArgs);
}

﻿namespace Saku_Overclock.Behaviors;

public enum NavigationViewHeaderMode
{
    Always,
    Never,
    Minimal
}
